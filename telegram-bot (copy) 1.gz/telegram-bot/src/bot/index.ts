import express from "express";
import TelegramBot from "node-telegram-bot-api";
import { registerHandlers } from "./handlers";

// ---------------- Keep-alive сервер ----------------
const app = express();
const PORT = process.env.PORT || 8080;

app.get("/", (req, res) => res.send("Bot is alive!"));

app.listen(PORT, () => {
  console.log(`✅ Keep-alive server running on port ${PORT}`);
});

// ---------------- Запуск Telegram бота ----------------
export function startBot(): void {
  const token = process.env["TELEGRAM_BOT_TOKEN"];
  if (!token) {
    console.error("❌ TELEGRAM_BOT_TOKEN не вказано. Бот не запущено.");
    return;
  }

  const bot = new TelegramBot(token, { polling: true });

  bot.setMyCommands([
    { command: "start", description: "🛍 Відкрити каталог" },
  ]);

  registerHandlers(bot);

  console.log("✅ Telegram-бот запущено (polling)");
}

// ---------------- Старт бота ----------------
startBot();